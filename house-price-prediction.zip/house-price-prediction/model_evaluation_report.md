# Model Evaluation Report — House Price Prediction

## Dataset
- **Records:** 300 properties (41 cities represented in Location/Property_Type categories)
- **Raw features:** Area, Bedrooms, Bathrooms, Age, Location, Property_Type
- **Encoded features:** 8 (after one-hot encoding of Location and Property_Type)
- **Train/Test split:** 80% / 20% (random_state = 42)
- **Missing values:** None found

## Results Summary

| Model | MAE (₹) | MSE | RMSE (₹) | R² Score |
|---|---|---|---|---|
| Linear Regression (sklearn) | 2,188,736 | 8.45e12 | 2,907,633 | 0.9406 |
| Linear Regression (from scratch) | 2,188,736 | 8.45e12 | 2,907,633 | 0.9406 |
| Polynomial Regression (deg 2) | 2,367,902 | 1.01e13 | 3,180,590 | 0.9290 |
| Decision Tree Regressor | 2,388,254 | 9.63e12 | 3,103,414 | 0.9324 |
| **Random Forest Regressor** | **1,483,832** | **4.14e12** | **2,034,472** | **0.9709** |

**Best model: Random Forest Regressor** — lowest error and highest R² across all metrics.

## Key Findings

1. **Area is the dominant predictor.** It carries ~69% of the Random Forest's feature importance and the strongest correlation (0.80) with Price.
2. **Location matters significantly.** Rural properties are priced well below City Center (the baseline in the one-hot encoding), and Suburb sits in between.
3. **From-scratch vs sklearn Linear Regression** produced virtually identical coefficients and metrics, confirming the Normal Equation implementation is correct.
4. **Non-linear models outperform linear ones.** Random Forest beats Linear Regression on every metric, indicating real interactions/non-linearities between features and price that a straight-line model can't capture. Polynomial Regression and a single Decision Tree did not outperform Linear Regression, likely due to overfitting risk on a modest 300-row dataset.
5. **Practical takeaway:** Random Forest is recommended as the production model, with Area and Location as the two features to prioritize for any simplified or interpretable version.

## Visualizations
- `relationships_overview.png` — Area/Bedrooms/Location/Property_Type vs Price
- `correlation_heatmap.png` — numeric feature correlation
- `predictions_vs_actual.png` — Linear Regression predictions vs actual
- `predictions_vs_actual_best_model.png` — Random Forest predictions vs actual
- `model_comparison_r2.png`, `model_comparison_mae.png` — model comparison bar charts
- `linear_coefficients.png` — top 10 Linear Regression coefficients
- `rf_feature_importance.png` — top 10 Random Forest feature importances
